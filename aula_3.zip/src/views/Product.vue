<template>
  <div>
      <img :src="currentProduct.image" alt="" style="width: 250px">
      <h2>{{currentProduct.name}}</h2>
      <p>Preço: {{currentProduct.price}}</p>
      <button @click="$emit('addToCart')">Comprar</button>
  </div>
</template>

<script>
export default {
    props: ["products"],
    computed: {
        currentProduct() {
            return this.products[this.$route.params.id]
        }
    }
}
</script>

<style>

</style>