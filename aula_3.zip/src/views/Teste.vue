/* eslint-disable no-console */
<template>
  <div>teste</div>
</template>

<script>
export default {
    props: {},
    computed: {},
    created() {
        console.log("CREATED: carrega os dados")
    },
    mounted() {
        console.log("MOUNTED: modificando o DOM")
    },
    destroyed() {
        console.log("DESTROYED: destruindo o componente")
    }
}
</script>

<style>

</style>