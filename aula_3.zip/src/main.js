import Vue from 'vue'
import App from './App.vue'
import VueRouter from "vue-router"
import Home from "./views/Home"
import Product from "./views/Product"
import Teste from "./views/Teste"

Vue.use(VueRouter)
const router = new VueRouter({
  routes: [
    {
      path: "/",
      component: Home
    },
    {
      path: "/product/:id",
      component: Product
    }, {
      path: "/teste",
      component: Teste
    }
  ]
})

new Vue({
  render: h => h(App),
  router
}).$mount('#app')
