import VueRouter from "vue-router";
import App from "."
import Teste from "@/components/Teste"

const routes = [
    {
        path: "/",
        component: App
    }, {
        path: "/teste",
        component: Teste
    }
]

const router = new VueRouter({
    routes
})

export default router