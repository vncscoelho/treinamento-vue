<template>
  <div>
    <h1>Bem vindo a minha loja</h1>
    <ul>
      <li v-for="(item, index) in products" :key="item.id">
        <router-link :to="`/product/${index}`">
          {{item.name}}
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["products"]
}
</script>