<template>
  <div id="app">
    <router-link to="/">Lista de produtos</router-link>
    <p>
      Produtos no carrinho: {{carrinho}}
    </p>
    <router-view @addToCart="carrinho++" :products="products"></router-view>
  </div>
</template>

<script>
import products from "@/assets/products.json"

export default {
  data() {
    return {
      carrinho: 0
    }
  },
  computed: {
    products() {
      return products
    }
  }
}
</script>
